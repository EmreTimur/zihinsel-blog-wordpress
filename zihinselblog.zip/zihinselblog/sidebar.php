<div class="col-xs-3 solkolon">
<h4>-<h4>

<ul class="list-unstyled liste1">
<?php wp_list_cats('sort_column=name&hierarchical=0'); ?>
</ul>


</div>