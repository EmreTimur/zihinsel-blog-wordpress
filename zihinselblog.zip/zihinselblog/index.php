<?php get_header(); ?>


<?php get_sidebar(); ?>
<div class="col-xs-9">
<div class="sagkolon">

     
<p style="font-family: 'Montserrat', sans-serif;">
Korkma, sönmez bu şafaklarda yüzen al sancak; <br>
Sönmeden yurdumun üstünde tüten en son ocak.<br>
O benim milletimin yıldızıdır, parlayacak;<br>
O benimdir, o benim milletimindir ancak.<br>
<br><br>
Çatma, kurban olayım, çehreni ey nazlı hilâl!<br>
Kahraman ırkıma bir gül! Ne bu şiddet, bu celâl?<br>
Sana olmaz dökülen kanlarımız sonra helâl...<br>
Hakkıdır, Hakk'a tapan, milletimin istiklâl!<br>


</p>
</div>
</div>
<div class="col-xs-3 solkolon soz" style="overflow:hidden;">
      <center>
<h4 style="text-shadow: 2px 2px 3px rebeccapurple;"><?php echo ot_get_option( 'soz_ad' ) ?></h4>
<img src="<?php echo ot_get_option( 'soz_resmi' ) ?>" width="150" height="200"  class="img-circle">
<p><?php echo ot_get_option( 'soz_yazisi' ) ?></p>
</center>
</div>
 <center>
      <div class="portalahg">
            Portala Hoşgeldiniz
      </div>
<img width="300" src="https://68.media.tumblr.com/590c388d7289fca53dbf90a7c02d7f48/tumblr_nukn86lRId1urj5gko1_500.gif" class="img-circle iskelet"/>
<br>
<div class="dizi">
<img src="<?php bloginfo('template_url'); ?>/img/ismail.png">
<img class="behzat" src="<?php bloginfo('template_url'); ?>/img/behzat.png">
</div>
</div>

 </center>

<?php get_footer(); ?>