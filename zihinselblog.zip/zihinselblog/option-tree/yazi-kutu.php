<?php


/**
 * Initialize the meta boxes. 
 */
add_action( 'admin_init', 'yazikutusu' );

function yazikutusu() {

  $my_meta_box = array(
    'id'        => 'my_meta_box',
    'title'     => 'Yazı Ayarları',
    'desc'      => '',
    'pages'     => array( 'proje' ),
    'context'   => 'normal',
    'priority'  => 'high',
    'fields'    => array(

 array(
        'label'       => __( 'Genel Yazı Ayarları', 'theme-text-domain' ),
        'id'          => 'genelayarlar',
        'type'        => 'tab'
      ),

	
	   array(
        'label'       => __( 'Proje Açıklama Kısmı', 'theme-text-domain' ),
        'id'          => 'aciklama',
        'type'        => 'text',
      ),
 

    ) 
  );
  
  ot_register_meta_box( $my_meta_box );

}




?>