<?php
/**
 * Initialize the custom theme options.
 */
add_action( 'admin_init', 'custom_theme_options' );

/**
 * Build the custom settings & update OptionTree.
 */
function custom_theme_options() {
  
  /* OptionTree is not loaded yet */
  if ( ! function_exists( 'ot_settings_id' ) )
    return false;
    
  /**
   * Get a copy of the saved settings array. 
   */
  $saved_settings = get_option( ot_settings_id(), array() );
  
  /**
   * Custom settings array that will eventually be 
   * passes to the OptionTree Settings API Class.
   */
  $custom_settings = array( 
    'contextual_help' => array( 
      'sidebar'       => ''
    ),
    'sections'        => array( 
      array(
        'id'          => 'diger',
        'title'       => 'Diğer Ayarlar'
      ),
      array(
        'id'          => 'soz',
        'title'       => 'Söz Kısmı'
      ),
      
      
    ),
    'settings'        => array( 
      array(
        'id'          => 'zon-h',
        'label'       => 'Zone-H Linkiniz',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'diger',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'soz_ad',
        'label'       => 'Sözü Söyleyen Adı Kısmı',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'soz',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'soz_resmi',
        'label'       => 'Resmi sadece resim linki',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'soz',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'soz_yazisi',
        'label'       => 'Sözü Buraya Yaz',
        'desc'        => '',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'soz',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
    )
  );
  update_option('of_template',$options);
  update_option('of_themename',$themename);   
update_option('of_shortname',$shortname);
  
  /* allow settings to be filtered before saving */
  $custom_settings = apply_filters( ot_settings_id() . '_args', $custom_settings );
  
  /* settings are not the same update the DB */
  if ( $saved_settings !== $custom_settings ) {
    update_option( ot_settings_id(), $custom_settings ); 
  }
  
  /* Lets OptionTree know the UI Builder is being overridden */
  global $ot_has_custom_theme_options;
  $ot_has_custom_theme_options = true;
  
}