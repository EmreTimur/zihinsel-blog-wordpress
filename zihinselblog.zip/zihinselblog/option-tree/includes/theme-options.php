<?php
/**
 * Initialize the custom theme options.
 */
add_action( 'init', 'custom_theme_options' );

/**
 * Build the custom settings & update OptionTree.
 */
function custom_theme_options() {
  
  /* OptionTree is not loaded yet, or this is not an admin request */
  if ( ! function_exists( 'ot_settings_id' ) || ! is_admin() )
    return false;
    
  /**
   * Get a copy of the saved settings array. 
   */
  $saved_settings = get_option( ot_settings_id(), array() );
  
  /**
   * Custom settings array that will eventually be 
   * passes to the OptionTree Settings API Class.
   */
  $custom_settings = array( 
    'contextual_help' => array( 
      'sidebar'       => ''
    ),
    'sections'        => array( 
    
  array(
        'id'          => 'general',
        'title'       => 'Genel Ayarlar'
      ),
      array(
        'id'          => 'sayfa',
        'title'       => 'Sayfa & Single Ayarları'
      ),
    
      array(
        'id'          => 'social',
        'title'       => 'Sosyal Medya'
      ),
      array(
        'id'          => 'slider',
        'title'       => 'Sliders & Carousel'
      ),
      array(
        'id'          => 'style',
        'title'       => 'Stil & Renk Ayarları'
      ),
      array(
        'id'          => 'arkaplan',
        'title'       => 'Arkaplan Resim Ekleme'
      ),
  array(
        'id'          => 'reklam',
        'title'       => 'Site Reklam Alanları'
      )
    ),
    'settings'        => array( 
     


 array(
        'id'          => 'logo',
        'label'       => 'Logo',
        'desc'        => 'Web Sitesi Logonuzu Seçiniz (İdeal Boyut 300x150)',
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'general',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
       
           array(
        'id'          => 'cr',
        'label'       => 'Footer Yazınız',
        'desc'        => 'Footer için görünmesi istediğiniz yazıyı giriniz',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'general',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),

           array(
        'id'          => 'adet',
        'label'       => 'Döngü İçerik Sayınız (Dizi + Film , Dizi Anasayfa 1, Film Anasayfa 1)',
        'desc'        => 'Sitede Bulunan Genel Post Adetlerinizi Giriniz.(Sayfalama Bu Gireceğiniz Sayıdan İtibaren Yapılacaktır.)',
        'std'         => '5',
        'type'        => 'text',
        'section'     => 'general',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),

           array(
        'id'          => 'adeti',
        'label'       => 'Döngü İçerik Sayınız (Dizi 2, En Çok İzlenenler, Dizi Bölümleri, En Çok İzlenen Filmler, Film 2)',
        'desc'        => 'Sitede Bulunan Genel Post Adetlerinizi Giriniz.(Sayfalama Bu Gireceğiniz Sayıdan İtibaren Yapılacaktır.)',
        'std'         => '12',
        'type'        => 'text',
        'section'     => 'general',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),


           array(
        'id'          => 'ikonlar',
        'label'       => 'İkonları Aç/Kapa',
        'desc'        => 'Konu Meta Etiketleri Yanında Bulunan İkonları Kapatıp, İlgili ismini Yazdırabilirsiniz.',
        'std'         => '',
        'type'        => 'on-off',
        'section'     => 'general',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),

           array(
        'id'          => 'video_oncesi',
        'label'       => 'Video Öncesi Reklamları Aç',
        'std'         => 'off',
        'type'        => 'on-off',
        'section'     => 'general',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
array(
        'id'          => 'video_oncesi_reklam_suresi',
        'label'       => 'Lütfen Video Öncesi Reklam Süresini Saniye Cinsinden Giriniz.',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'general',
        'operator'    => 'and',
        'condition'   => 'video_oncesi:is(on),video_oncesi:not()'
      ),


array(
        'id'          => 'video_oncesi_reklam_kodu',
        'label'       => 'Lütfen Video Öncesi Reklam Kodunuzu Giriniz.',
        'std'         => '',
        'type'        => 'textarea-simple',
        'section'     => 'general',
        'operator'    => 'and',
        'condition'   => 'video_oncesi:is(on),video_oncesi:not()'
      ),
     array(
        'id'          => 'simgeler',
        'label'       => 'Simgeleri Aç/Kapa',
        'desc'        => 'Konu İçlerinde ve Belirli Alanlarda Bulunan Simgeleri Açıp Kapatabilirsiniz.',
        'std'         => '',
        'type'        => 'on-off',
        'section'     => 'general',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),

           array(
        'id'          => 'harici_kat',
        'label'       => 'Bileşenler Kategorisinden Çıkarmak İstediğiniz Kategoriler',
        'std'         => '',
        'desc'         => 'Çıkarmak istediğiniz Kategorilerin Numaralarını Belirleyip Başına - Ekleyerek Ekleyiniz, Birden fazla ekleme yapacaksanız eğer araya virgün ekleyiniz. <b> Örnek -15,-17,-4</b>',
        'type'        => 'text',
        'section'     => 'general',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),


      array(
        'id'          => 'sc',
        'label'       => 'Slider & Carousel Ayarları',
        'desc'        => 'Sayfalar dışında kalan alanlar için Slider & Carousel yapılandırması içindir.',
        'std'         => '',
        'type'        => 'select',
        'section'     => 'sayfa',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'choices'     => array( 
         
          array(
            'value'       => 's1',
            'label'       => '1/4',
            'src'         => ''
          ),
          array(
            'value'       => 's2',
            'label'       => '1/1',
            'src'         => ''
          ),
           array(
            'value'       => 's3',
            'label'       => 'Kişisel',
            'src'         => ''
          )
        )
      ),
array(
        'id'          => 'car_kisakod',
        'label'       => 'Slider & Carousel Kişisel Ayarı ',
        'desc'        => 'Eğerki Yukarıda ki Carousel veya Slider Görünümleri Hoşunuza Gitmediyse, <b>Kişisel</b> Seçeneğini Seçip Bu Alana Kısa Kodunuzu Ekleyebilirsiniz. ',
        'std'         => '',
        'type'        => 'textarea_simple',
        'section'     => 'sayfa',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),

      array(
        'id'          => 'dizi_robotu',
        'label'       => 'Dizi Robotu Sayfasını Seçiniz',
        'desc'        => 'Dizi Robotu Sayfasını Seçiniz.',
        'std'         => '',
        'type'        => 'page_select',
        'section'     => 'sayfa',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
            array(
        'id'          => 'film_robotu',
        'label'       => 'Film Robotu Sayfasını Seçiniz',
        'desc'        => 'Film Robotu Sayfasını Seçiniz.',
        'std'         => '',
        'type'        => 'page_select',
        'section'     => 'sayfa',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
                array(
        'id'          => 'kayit_ol',
        'label'       => 'Kayıt Ol Sayfasını Seçiniz',
        'desc'        => 'Kayıt Ol Sayfasını Seçiniz.',
        'std'         => '',
        'type'        => 'page_select',
        'section'     => 'sayfa',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
            array(
        'id'          => 'profil_duzenle',
        'label'       => 'Profil Düzenleme Sayfasını Seçiniz',
        'desc'        => 'Profil Düzenleme Sayfasını Seçiniz.',
        'std'         => '',
        'type'        => 'page_select',
        'section'     => 'sayfa',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
     
      array(
        'id'          => 'facebook',
        'label'       => 'Facebook',
        'desc'        => 'Facebook Kullanıcı Linki',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'social',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'twitter',
        'label'       => 'Twitter',
        'desc'        => 'Twitter Kullanıcı Linki',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'social',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'gplus',
        'label'       => 'Google Plus',
        'desc'        => 'Google+ ID',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'social',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      
      array(
        'id'          => 'carousel',
        'label'       => 'Carousel',
        'std'         => '',
        'type'        => 'list-item',
        'section'     => 'slider',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'settings'    => array( 
          array(
            'id'          => 'carousel_resim',
            'label'       => 'Resim',
            'desc'        => 'Lütfen Carousel Resminizi Seçiniz.',
            'std'         => '',
            'type'        => 'upload',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'min_max_step'=> '',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and'
          ),
          array(
            'id'          => 'carousel_link',
            'label'       => 'Link',
            'desc'        => 'Lütfen Carousel Linkini Giriniz.',
            'std'         => '',
            'type'        => 'text',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'min_max_step'=> '',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and'
          )
        )
      ),
      
   array(
        'id'          => 'arkaplan_dizi_resim',
        'label'       => 'Dizi Arkaplanlarına Ekstra Resim Ekleme',
        'std'         => '',
        'type'        => 'list-item',
        'section'     => 'arkaplan',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'settings'    => array( 
          array(
            'id'          => 'dizi_resim_ark',
            'label'       => 'Resim',
            'desc'        => 'Lütfen Arkaplan Resminizi Seçiniz.',
            'std'         => '',
            'type'        => 'upload',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'min_max_step'=> '',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and'
          ),
         )
      ),
         array(
        'id'          => 'arkaplan_film_resim',
        'label'       => 'Film Arkaplan Ekstra Resim Ekleme',
        'std'         => '',
        'type'        => 'list-item',
        'section'     => 'arkaplan',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'settings'    => array( 
          array(
            'id'          => 'film_resim_ark',
            'label'       => 'Resim',
            'desc'        => 'Lütfen Arkaplan Resminizi Seçiniz.',
            'std'         => '',
            'type'        => 'upload',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'min_max_step'=> '',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and'
          ),
         
        )
      ),
         
           array(
        'id'          => 'style',
        'label'       => 'Stil Renk Kodlamasını Aç',
        'desc'        => 'Css Renklerini Kendinize Göre Özelleştirebilirsiniz..',
        'std'         => 'off',
        'type'        => 'on-off',
        'section'     => 'style',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
array(
        'id'          => 'turuncu',
        'label'       => 'Tema Genel Renkleri',
        'desc'        => 'Tema için Turuncu ve Tonu Gözüken Renkler',
        'std'         => '',
        'type'        => 'colorpicker',
        'section'     => 'style',
        'operator'    => 'and',
        'condition'   => 'style:is(on),style:not()'
      ),
array(
        'id'          => 'siyah',
        'label'       => 'Tema Genel Renkleri',
        'desc'        => 'Tema için Siyah ve Tonu Gözüken Renkler',
        'std'         => '',
        'type'        => 'colorpicker',
        'section'     => 'style',
        'operator'    => 'and',
        'condition'   => 'style:is(on),style:not()'
      ),



array(
        'id'          => 'kirmizi',
        'label'       => 'Tema Genel Kırmızı Renkler',
        'desc'        => 'Tema İçerisinde Seyrek Olarak Bulunan Kırmızı Renkleri Düzenleyebilirsiniz.',
        'std'         => '',
        'type'        => 'colorpicker',
        'section'     => 'style',
        'operator'    => 'and',
        'condition'   => 'style:is(on),style:not()'
      ),
  array(
        'id'          => 'reklam',
        'label'       => 'Masaüstü Reklam Alanları',
        'desc'        => 'Masaüstü Reklam Alanlarını Aktif Ediniz.',
        'std'         => 'off',
        'type'        => 'on-off',
        'section'     => 'reklam',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),

array(
        'id'          => 'header-tab',
        'label'       => 'Header',
        'std'         => '',
        'type'        => 'tab',
        'section'     => 'reklam',
        'operator'    => 'and',
        'condition'   => 'reklam:is(on),reklam:not()'
      ),
array(
        'id'          => 'yediikisekizmasaustu',
        'label'       => 'Header 728x90 Reklam Kodunuz',
        'std'         => '',
        'type'        => 'textarea-simple',
        'section'     => 'reklam',
        'operator'    => 'and',
        'condition'   => 'reklam:is(on),reklam:not()'
      ),
array(
        'id'          => 'dortaltisekizmasaustu',
        'label'       => 'Header 468x60 Reklam Kodunuz',
        'std'         => '',
        'type'        => 'textarea-simple',
        'section'     => 'reklam',
        'operator'    => 'and',
        'condition'   => 'reklam:is(on),reklam:not()'
      ),
array(
        'id'          => 'sidebar-tab',
        'label'       => 'Sidebar',
        'std'         => '',
        'type'        => 'tab',
        'section'     => 'reklam',
        'operator'    => 'and',
        'condition'   => 'reklam:is(on),reklam:not()'
      ),
array(
        'id'          => 'ikiyuzikiyuzsagmasaustu',
        'label'       => 'Sidebar Sağ 200x200 Reklam Kodunuz',
        'std'         => '',
        'type'        => 'textarea-simple',
        'section'     => 'reklam',
        'operator'    => 'and',
        'condition'   => 'reklam:is(on),reklam:not()'
      ),
array(
        'id'          => 'ikiyuzikiyuzsolmasaustu',
        'label'       => 'Sidebar Sol 200x200 Reklam Kodunuz',
        'std'         => '',
        'type'        => 'textarea-simple',
        'section'     => 'reklam',
        'operator'    => 'and',
        'condition'   => 'reklam:is(on),reklam:not()'
      ),
array(
        'id'          => 'konu-tab',
        'label'       => 'Konu',
        'std'         => '',
        'type'        => 'tab',
        'section'     => 'reklam',
        'operator'    => 'and',
        'condition'   => 'reklam:is(on),reklam:not()'
      ),

array(
        'id'          => 'dortaltisekizkonumasaustu',
        'label'       => 'Film ve Dizi Bölümleri içeriği 468x60 Reklam Kodunuz',
        'std'         => '',
        'type'        => 'textarea-simple',
        'section'     => 'reklam',
        'operator'    => 'and',
        'condition'   => 'reklam:is(on),reklam:not()'
      ),

array(
        'id'          => 'karay-tab',
        'label'       => 'Kayan Reklamlar',
        'std'         => '',
        'type'        => 'tab',
        'section'     => 'reklam',
        'operator'    => 'and',
        'condition'   => 'reklam:is(on),reklam:not()'
      ),

array(
        'id'          => 'sagdakayar',
        'label'       => 'Sağda Kayan Reklam Kodunuz',
        'std'         => '',
        'type'        => 'textarea-simple',
        'section'     => 'reklam',
        'operator'    => 'and',
        'condition'   => 'reklam:is(on),reklam:not()'
      ),

array(
        'id'          => 'soldakayar',
        'label'       => 'Solda Kayan Reklam Kodunuz',
        'std'         => '',
        'type'        => 'textarea-simple',
        'section'     => 'reklam',
        'operator'    => 'and',
        'condition'   => 'reklam:is(on),reklam:not()'
      ),

    )
  );
  
  /* allow settings to be filtered before saving */
  $custom_settings = apply_filters( ot_settings_id() . '_args', $custom_settings );
  
  /* settings are not the same update the DB */
  if ( $saved_settings !== $custom_settings ) {
    update_option( ot_settings_id(), $custom_settings ); 
  }
  
  /* Lets OptionTree know the UI Builder is being overridden */
  global $ot_has_custom_theme_options;
  $ot_has_custom_theme_options = true;
  
}