<?php
/* Template Name: Bağlantı */
 get_header(); ?>

 <?php get_sidebar(); ?>
<div class="col-xs-9">
<div class="sagkolon">
    <center>
	Soyumla her zaman iftihar etmişimdir <br>
	ilk fotoğrafda gördüğünüz kişi babamın babası exploit-dbyi keşfeden adam<br>
	ikinci fotoğrafta gördüğünüz kişi anne tarafından dedem cssin mucidi<br>
	son fotoğrafda gördüğünüz kişi ise ailenin yüz karası bilgisayar bile kullanmazdı<br>
<img src="http://img01.alkislarlayasiyorum.com/ayrshots/136/ailenin-yuzkarasi-sigara-bile-icmezdi-kemal-sunal_136901-11760_640x360.jpg">

    </center>
	</div>
	</div> 
	
	<?php get_footer(); ?>