</body>

<div class="fuutir">
© 2017 ~ 
Bu site demo sitesidir indirmek için <a href="https://github.com/atamavi/zihinselblogcss" target="_blank">tıklayın</a>

</div>
</html>