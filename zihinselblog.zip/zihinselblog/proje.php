<?php
/* Template Name: Proje Sayfası */
 get_header(); ?>
<?php get_sidebar(); ?>
<div class="col-xs-9">
<div class="sagkolon vut">
<div class="projebaslik">Projelerimiz</div>
<div class="projeslogan">Kodlamış olduğumuz araçlara bu kısımdan erişebilirsiniz.</div>
<?php
if ( get_query_var('paged') ) {

    $paged = get_query_var('paged');

} elseif ( get_query_var('page') ) {

    $paged = get_query_var('page');

} else {

    $paged = 1;

}
$temp = $wp_query;
$wp_query = null;
$wp_query = new WP_Query();
$wp_query->query('post_type=proje' . '&paged=' . $paged . '&posts_per_page=10');
?>
<?php while ( $wp_query->have_posts() ) : $wp_query->the_post(); ?>
<div class="projeicerik">
  <a href=""><font><?php the_title(); ?></font></a>
</div>
<div class="projeresim">
<?php the_post_thumbnail(); ?>
<font><?php $aciklama = get_post_meta($post->ID, "aciklama", true); if ($aciklama == true) { ?>
<?php echo get_post_meta($post->ID, "aciklama", true); ?><?php } ?></font>
</div>
 <?php endwhile; ?>
<?php wp_reset_query(); ?>

</div></div>

<?php get_footer(); ?>