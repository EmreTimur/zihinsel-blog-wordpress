<html>
<head>
<title><?php wp_title('-', true, 'right'); ?></title>
<meta charset="utf8">
        <link href="https://fonts.googleapis.com/css?family=Press+Start+2P" rel="stylesheet">
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/css/bootstrap.min.css"/>
        <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/css/bootstrap.css"/>
		 <link href="<?php bloginfo('template_url'); ?>/style.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Oswald|Oxygen|PT+Sans|Raleway" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">

<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">

<style>
body{

background-color: #1a1a1a;
background-origin:border-box;

font-family: 'Raleway', sans-serif;
}
.logo{

            text-align: center;
            font-weight:bolder;
            text-shadow: 1px 2px 2px black;
            width:100%;
            height:40px;
            background-color:#8c8c8c;
                background-color: #333;
            font-size: xx-large;
            color:white;
            font-family: 'Press Start 2P', cursive !important;


}
.logo:hover{
    background-image: url('https://media.giphy.com/media/quEsMOrr3hmQ8/giphy.gif')
}
.logo span{
      color:black;
}
.logo span:hover{
      color:red;
}
.orta{
      margin: 0 auto;
        width:960px;
              text-align: center;
            font-weight:bolder;
            margin-top: 15px;

}
.buton{

    color:#339367;
    letter-spacing: 1px;
    overflow:hidden;
    background-color: #333;
    width:150px;
}
.buton:hover{
background-color: #333;
background: black;
border-radius: 10px;
border: 2px solid #339367;


}
.icerik{



}
.solkolon,.sagkolon{
	background-color: rgba(0,0,0,0.8);
	border-radius:10px;
	padding: 15px;
	color:white;
  margin-top: 15px;
  background-color: #333;


      }
.solkolon ul li a{
		color:#339367;
		text-decoration:none !important;

            }

		.solkolon ul li{
		border-bottom:1px dotted white;

            }
            .sagkolon{
                width:100%;
                padding: 45px;
                		color:darkgoldenrod;

            }

.fuutir {
width:100%;
position:fixed;
left:0px;
bottom:0px;
background: black;
text-align: center;
color:#339367;

}
.aktif{
 border: 2px solid #339367;

color:#339367;
background: black;
border-radius: 10px;
}
@media screen and (max-width:865px) {

body{
   font-size: 10px;
   max-height: 500px;
}

.orta{width:100px;}

.solkolon,.sagkolon,.liste1{

  font-size:10px !important;
}

}

.iskelet{

transition: all 1es;

}
.iskelet:hover{
                    border: 5px solid #339367;


}
.portalahg{
              font-size: large;
            color:white;
            font-family: 'Press Start 2P', cursive !important;
            text-shadow: 3px 3px 6px green;

}

.dizi img
{
z-index:8888;
position:fixed;
_position:absolute;
bottom:0px;
right:0px;
}
.dizi .behzat{
  z-index:9999;
position:fixed;
_position:absolute;
bottom:0px;
left:0px;   
 
}
      
.soz {
top:-100;
}
.blog a  {
font-size:15px !important;
    background-color:#333 !important; 
 
}


.blog a:hover  {
    font-weight: bolder !important;
    font-size: 20px !important;
    border: 5px solid #4fde7f;
    color:red !important;
    background-image: url('https://media.giphy.com/media/quEsMOrr3hmQ8/giphy.gif') 
}

</style>
</head>
<body class="container">

<div class="logo">

<font>ZihinselBl<span class="glyphicon glyphicon-off" aria-hidden="true" ></span></font><font style="color:red!important;">g</font>
</div>


<div class="orta">


<a href="<?php bloginfo('url'); ?>"><button class="buton" type="button">Anasayfa</button></a>
<a href="<?php bloginfo('url'); ?>/blog/"><button class="buton" type="button">Blog</button></a>
<a href="<?php bloginfo('url'); ?>/projeler/"><button class="buton" type="button">Proje</button></a>
<a href="<?php echo ot_get_option( 'zon-h' ) ?>"><button class="buton" type="button">Zone-H</button></a>
<a href="<?php bloginfo('url'); ?>/baglanti/"><button class="buton" type="button">Baglantı</button></a>

</div>