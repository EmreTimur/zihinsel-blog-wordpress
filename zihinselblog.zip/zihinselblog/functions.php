<?php
function wpdocs_filter_wp_title($title, $sep){
global $paged, $page;
if ( is_feed() )
return $title;
$title .= get_bloginfo( 'name' );
$site_description = get_bloginfo( 'description', 'display' );
if ( $site_description && ( is_home() || is_front_page() ) )
$title = "$title $sep $site_description";
if ( $paged >= 2 || $page >= 2 )
$title = "$title $sep " . sprintf( __( 'SAYFA %s', 'twentytwelve' ), max( $paged, $page ) );
 return $title;
}
add_filter( 'wp_title', 'wpdocs_filter_wp_title', 10, 2 );

function register_cpt_proje() {

    $labels = array( 
        'name' => _x( 'Proje', 'proje' ),
        'singular_name' => _x( 'Proje', 'proje' ),
        'add_new' => _x( 'Yeni Proje Ekle', 'proje' ),
        'add_new_item' => _x( 'Yeni Proje Ekle', 'proje' ),
        'edit_item' => _x( 'Düzenle', 'proje' ),
        'new_item' => _x( 'Yeni Proje Ekle', 'proje' ),
        'view_item' => _x( 'Görüntülenme', 'proje' ),
        'search_items' => _x( 'Ara', 'proje' ),
        'not_found' => _x( 'Bulunamadı', 'proje' ),
        'not_found_in_trash' => _x( 'Bulunamadı', 'proje' ),
        'parent_item_colon' => _x( 'Parent Proje:', 'proje' ),
        'menu_name' => _x( 'Proje', 'proje' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        
        'supports' => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'trackbacks', 'custom-fields', 'comments', 'revisions', 'page-attributes' ),
        'taxonomies' => array( 'category', 'post_tag', 'page-category' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => get_bloginfo( 'template_directory' ) . '/images/proje.gif',
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );

    register_post_type( 'proje', $args );
}
add_theme_support( 'post-thumbnails', array( 'post' ) );
add_theme_support( 'post-thumbnails', array( 'proje' ) );
set_post_thumbnail_size( 160, 160, true );
add_action( 'init', 'register_cpt_proje' );
// Theme option
        add_filter( 'ot_show_pages', '__return_false' ); //Production - false
        add_filter( 'ot_show_new_layout', '__return_false' );
        add_filter( 'ot_theme_mode', '__return_true' );
        add_filter( 'ot_child_theme_mode', '__return_false' );
        load_template( trailingslashit( get_template_directory() ) . 'option-tree/ot-loader.php' );
        load_template( trailingslashit( get_template_directory() ) . 'option-tree/theme-options.php' );
        load_template( trailingslashit( get_template_directory() ) . 'option-tree/yazi-kutu.php' );
?>