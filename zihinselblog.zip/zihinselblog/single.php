<?php get_header(); ?>

<div class="col-xs-3 solkolon" style="overflow:hidden;">
      <center>
<h4 style="text-shadow: 2px 2px 3px rebeccapurple;"><?php echo ot_get_option( 'soz_ad' ) ?></h4>
<img src="<?php echo ot_get_option( 'soz_resmi' ) ?>" width="150" height="200"  class="img-circle">
<p><?php echo ot_get_option( 'soz_yazisi' ) ?></p>
</center>
</div>

<div class="col-xs-9">
<div class="sagkolon yazii">
<font>
<?php the_content(); ?>
</font>

</div></div>
<?php get_footer(); ?>