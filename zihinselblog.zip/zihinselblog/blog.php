<?php
/* Template Name: Blog */
 get_header(); ?>
 <?php get_sidebar(); ?>
 <div class="col-xs-9">
<div class="sagkolon">

<ul class="list-group blog">
<?php
if ( get_query_var('paged') ) {

    $paged = get_query_var('paged');

} elseif ( get_query_var('page') ) {

    $paged = get_query_var('page');

} else {

    $paged = 1;

}
$temp = $wp_query;
$wp_query = null;
$wp_query = new WP_Query();
$wp_query->query('post_type=post' . '&paged=' . $paged . '&posts_per_page=18');
?>
<?php while ( $wp_query->have_posts() ) : $wp_query->the_post(); ?>
  <li><a href="<?php the_permalink(); ?>" class="list-group-item"><?php the_title(); ?></a> </li>
  <?php endwhile; ?>
<?php wp_reset_query(); ?>
</ul>

</div></div>
<?php get_footer(); ?>